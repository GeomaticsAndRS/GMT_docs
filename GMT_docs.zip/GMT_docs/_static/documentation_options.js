var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: '5.4.4',
    LANGUAGE: 'zh_CN',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};